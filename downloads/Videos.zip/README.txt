These videos are to engage the students and help them relate pressure to their everyday lives.
The audio is irrelevant and can be muted.

Video 1: Water Guns
The video is actually explaining how to make an electric stun gun using water, but the purpose
of the video in our demonstration is to show how decreasing volume can increase pressure on the
water causing it to move and leave the tip of the gun.

Video 2: Inflatable Toy
The video shows how a machine pumping air particles into the toy causes the pressure to
increase, which makes the air push against the inner walls and increase the volume in order
to try to lower the pressure to make it the same as it was before.

Video 3: Popcorn
The video shows a slow-motion popcorn kernel exploding into puffy white goodness. The reason
this happens is because when you add energy to a system (the kernel) then the particles inside
(water particles in this case) capture that energy and increase the pressure inside the system.
Eventually, the pressure inside the kernel is so great that the walls of the kernel blow open
and release the steam, as you can observe in the video.